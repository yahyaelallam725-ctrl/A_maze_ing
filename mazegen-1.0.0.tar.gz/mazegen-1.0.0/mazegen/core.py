"""Core maze models and generator using DFS Recursive Backtracker algorithm."""

import random
from collections import deque
from typing import Generator, Optional


class Cell:
    """Represents a single cell in the maze grid.

    Attributes:
        x: Column index of the cell.
        y: Row index of the cell.
        north: True if north wall is closed.
        east: True if east wall is closed.
        south: True if south wall is closed.
        west: True if west wall is closed.
        visited: True if cell has been visited during generation.
        is_42: True if cell is part of the 42 pattern.
    """

    def __init__(self, x: int, y: int) -> None:
        """Initialize a Cell.

        Args:
            x: Column index.
            y: Row index.
        """
        self.x: int = x
        self.y: int = y
        self.north: bool = True
        self.east: bool = True
        self.south: bool = True
        self.west: bool = True
        self.visited: bool = False
        self.is_42: bool = False

    def __repr__(self) -> str:
        """Return string representation of the cell."""
        return f"Cell({self.x}, {self.y})"


class Maze:
    """Represents the maze grid.

    Example:
        >>> maze = Maze(width=10, height=10, entry=(0, 0), exit=(9, 9))
        >>> maze.create_grid()
    """

    def __init__(
        self,
        width: int,
        height: int,
        entry: tuple[int, int],
        exit: tuple[int, int],
        perfect: bool = True,
    ) -> None:
        """Initialize a Maze.

        Args:
            width: Number of columns.
            height: Number of rows.
            entry: Entry coordinates as (x, y).
            exit: Exit coordinates as (x, y).
            perfect: If True, generates a perfect maze (default True).
        """
        self.width: int = width
        self.height: int = height
        self.entry: tuple[int, int] = entry
        self.exit: tuple[int, int] = exit
        self.perfect: bool = perfect
        self.grid: list[list[Cell]] = []

    def create_grid(self) -> None:
        """Initialize the grid with Cell objects, all walls closed."""
        self.grid = []
        for i in range(self.height):
            rows: list[Cell] = []
            for j in range(self.width):
                rows.append(Cell(j, i))
            self.grid.append(rows)

    def is_inside(self, x: int, y: int) -> bool:
        """Check if coordinates are within maze bounds.

        Args:
            x: Column index.
            y: Row index.

        Returns:
            True if (x, y) is inside the maze.
        """
        return 0 <= x < self.width and 0 <= y < self.height

    def get_cell(self, x: int, y: int) -> Cell:
        """Get the cell at coordinates (x, y).

        Args:
            x: Column index.
            y: Row index.

        Returns:
            The Cell at (x, y).
        """
        return self.grid[y][x]

    def get_unvisited_neighbors(self, cell: Cell) -> list[Cell]:
        """Get unvisited non-42 neighbors of a cell.

        Args:
            cell: The cell to get neighbors for.

        Returns:
            List of unvisited neighboring cells.
        """
        x, y = cell.x, cell.y
        neighbors: list[Cell] = []
        for nx, ny in [(x, y + 1), (x, y - 1), (x + 1, y), (x - 1, y)]:
            if self.is_inside(nx, ny):
                n = self.get_cell(nx, ny)
                if not n.visited and not n.is_42:
                    neighbors.append(n)
        return neighbors

    def get_open_neighbors(self, cell: Cell) -> list[Cell]:
        """Get neighbors reachable through open walls.

        Args:
            cell: The cell to get neighbors for.

        Returns:
            List of cells reachable through open walls.
        """
        neighbors: list[Cell] = []
        x, y = cell.x, cell.y
        if not cell.north and self.is_inside(x, y - 1):
            neighbors.append(self.get_cell(x, y - 1))
        if not cell.east and self.is_inside(x + 1, y):
            neighbors.append(self.get_cell(x + 1, y))
        if not cell.south and self.is_inside(x, y + 1):
            neighbors.append(self.get_cell(x, y + 1))
        if not cell.west and self.is_inside(x - 1, y):
            neighbors.append(self.get_cell(x - 1, y))
        return neighbors

    def remove_wall_between(self, cell_a: Cell, cell_b: Cell) -> None:
        """Remove the wall between two adjacent cells.

        Args:
            cell_a: First cell.
            cell_b: Second cell (must be adjacent to cell_a).
        """
        if cell_a.x == cell_b.x:
            if cell_a.y > cell_b.y:
                cell_a.north = False
                cell_b.south = False
            else:
                cell_a.south = False
                cell_b.north = False
        if cell_a.y == cell_b.y:
            if cell_a.x > cell_b.x:
                cell_a.west = False
                cell_b.east = False
            else:
                cell_a.east = False
                cell_b.west = False


class MazeGenerator:
    """Generates a maze using the DFS Recursive Backtracker algorithm.

    Example:
        >>> from mazegen.core import Maze, MazeGenerator
        >>> maze = Maze(width=20, height=15, entry=(0, 0), exit=(19, 14))
        >>> maze.create_grid()
        >>> gen = MazeGenerator(maze, seed=42)
        >>> gen.generate()
        >>> path = gen.solve()
        >>> print(f"Path length: {len(path)} cells")
    """

    def __init__(self, maze: Maze, seed: Optional[int] = None) -> None:
        """Initialize the MazeGenerator.

        Args:
            maze: The Maze object to generate into.
            seed: Optional random seed for reproducibility.
        """
        self.maze: Maze = maze
        self.stack: list[Cell] = []
        if seed is not None:
            random.seed(seed)

    def make_imperfect(self, factor: float = 0.1) -> None:
        """Randomly remove extra walls to create loops in the maze.

        Args:
            factor: Fraction of cells to open extra walls for (default 0.1).
        """
        total_cells: int = self.maze.width * self.maze.height
        walls_to_remove: int = int(total_cells * factor)
        removed: int = 0
        attempts: int = 0
        while removed < walls_to_remove and attempts < total_cells * 10:
            attempts += 1
            x: int = random.randint(0, self.maze.width - 2)
            y: int = random.randint(0, self.maze.height - 2)
            cell: Cell = self.maze.get_cell(x, y)
            if getattr(cell, "is_42", False):
                continue
            neighbor: Cell = random.choice(
                [
                    self.maze.get_cell(x + 1, y),
                    self.maze.get_cell(x, y + 1),
                ]
            )
            if getattr(neighbor, "is_42", False):
                continue
            self.maze.remove_wall_between(cell, neighbor)
            removed += 1

    def generate(self) -> None:
        """
        Generate a perfect or imperfect maze using DFS Recursive Backtracker.
        Starts from cell (0, 0) and carves passages until all cells are
        visited. If maze.perfect is False, extra walls are removed to
        create loops.
        """
        self.stack = []
        cell: Cell = self.maze.get_cell(0, 0)
        cell.visited = True
        self.stack.append(cell)
        while len(self.stack) != 0:
            last_cell: Cell = self.stack[-1]
            neighbors: list[Cell] = self.maze.get_unvisited_neighbors(
                last_cell
                )
            if len(neighbors) != 0:
                random_cell: Cell = random.choice(neighbors)
                self.maze.remove_wall_between(last_cell, random_cell)
                self.stack.append(random_cell)
                random_cell.visited = True
            else:
                self.stack.pop()
        if not self.maze.perfect:
            self.make_imperfect()

    def place_42_pattern(self) -> None:
        """Place the 42 pattern in the center of the maze.

        Raises:
            ValueError: If the maze is too small to fit the pattern.
        """
        pattern_42: list[tuple[int, int]] = [
            (0, 0),
            (2, 0),
            (0, 1),
            (2, 1),
            (0, 2),
            (1, 2),
            (2, 2),
            (2, 3),
            (2, 4),
            (4, 0),
            (5, 0),
            (6, 0),
            (6, 1),
            (4, 2),
            (5, 2),
            (6, 2),
            (4, 3),
            (4, 4),
            (5, 4),
            (6, 4),
        ]
        pattern_width: int = 6
        pattern_height: int = 4
        if (
            self.maze.width <= pattern_width
            or self.maze.height <= pattern_height
        ):
            raise ValueError("42 pattern cannot be placed: maze is too small")
        start_x: int = (self.maze.width - pattern_width) // 2
        start_y: int = (self.maze.height - pattern_height) // 2
        for px, py in pattern_42:
            real_x: int = start_x + px
            real_y: int = start_y + py
            if (real_x, real_y) == self.maze.entry or (
                real_x,
                real_y,
            ) == self.maze.exit:
                print(
                    "please do not enter a cell that is on "
                    "the bounds of 42 pattern"
                )
                return
            cell = self.maze.get_cell(real_x, real_y)
            cell.north = True
            cell.east = True
            cell.south = True
            cell.west = True
            cell.is_42 = True

    def generate_animated(self) -> Generator[None, None, None]:
        """Generate the maze step by step, yielding after each wall removal.

        Yields:
            None after each wall removal for animation purposes.
        """
        self.stack = []
        cell: Cell = self.maze.get_cell(0, 0)
        cell.visited = True
        self.stack.append(cell)
        while len(self.stack) != 0:
            last_cell: Cell = self.stack[-1]
            neighbors: list[Cell] = self.maze.get_unvisited_neighbors(
                last_cell
            )
            if neighbors:
                random_cell: Cell = random.choice(neighbors)
                self.maze.remove_wall_between(last_cell, random_cell)
                self.stack.append(random_cell)
                random_cell.visited = True
                yield
            else:
                self.stack.pop()
        if not self.maze.perfect:
            self.make_imperfect()

    def solve(self) -> list[Cell]:
        """Find the shortest path from entry to exit using BFS.

        Returns:
            List of Cell objects from entry to exit (shortest path).
        """
        # the setup
        entry: Cell = self.maze.get_cell(*self.maze.entry)
        exit_: Cell = self.maze.get_cell(*self.maze.exit)
        # step 1: store each unvisited neighbor in a fifo queue
        queue: deque[Cell] = deque()
        queue.append(entry)
        # step 2: only visit unvisited cells
        visited: set[Cell] = set()
        visited.add(entry)
        # step 3: remember the path by saving child and parent cell
        came_from: dict[Cell, Optional[Cell]] = {}
        came_from[entry] = None  # entry has no parent
        while queue:
            current: Cell = queue.popleft()  # take from front - FIFO
            if current == exit_:
                break
            for neighbor in self.maze.get_open_neighbors(current):
                if neighbor not in visited:
                    visited.add(neighbor)
                    came_from[neighbor] = current
                    queue.append(neighbor)
        # step 4: reconstruct path from exit back to entry
        path: list[Cell] = []
        node: Optional[Cell] = exit_
        while node is not None:
            path.append(node)
            node = came_from[node]
        path.reverse()
        return path
