"""
mazegen - A reusable maze generator package using DFS Recursive Backtracker.
"""

__all__ = ["Cell", "Maze", "MazeGenerator"]
__version__ = "1.0.0"
