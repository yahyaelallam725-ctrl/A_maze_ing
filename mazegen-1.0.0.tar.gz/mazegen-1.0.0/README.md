# mazegen
A reusable Python maze generator package using the DFS Recursive Backtracker algorithm.
## Installation
```bash
pip install mazegen-1.0.0.tar.gz
```
## Quick Start
```python
from mazegen.core import Maze, MazeGenerator
# create maze
maze = Maze(width=20, height=15, entry=(0, 0), exit=(19, 14))
maze.create_grid()
# generate
gen = MazeGenerator(maze, seed=42)
gen.generate()
# solve
path = gen.solve()
print(f"Path length: {len(path)} cells")
for cell in path:
    print(f"  ({cell.x}, {cell.y})")
## Custom Parameters
```python
# custom size and seed for reproducibility
maze = Maze(width=30, height=20, entry=(0, 0), exit=(29, 19), perfect=True)
maze.create_grid()
gen = MazeGenerator(maze, seed=123)
gen.generate()
# imperfect maze (has loops)
maze2 = Maze(width=20, height=15, entry=(0, 0), exit=(19, 14), perfect=False)
maze2.create_grid()
gen2 = MazeGenerator(maze2)
gen2.generate()
## Accessing the Maze Structure
```python
# access individual cells
cell = maze.get_cell(x=5, y=3)
print(cell.north)   # True = wall closed
print(cell.east)    # False = wall open
print(cell.is_42)   # True if part of 42 pattern
# iterate over all cells
for row in maze.grid:
    for cell in row:
        print(f"({cell.x},{cell.y}): N={cell.north} E={cell.east} S={cell.south} W={cell.west}")
# get the solution path
path = gen.solve()  # list of Cell objects from entry to exit
## Animation Support
```python
# step-by-step generation for animation
gen = MazeGenerator(maze)
for _ in gen.generate_animated():
    # render maze state here after each wall removal
    pass
